package Data;


import java.util.ArrayList;

public class ProductDetailsUsingList 
{
	public static ArrayList<ProdDetail> datas = new ArrayList<ProdDetail>();			// ArrayList to store multiple objects of Products

	public static void ProductDetailsUsingList()
	{
		ProdDetail a1 = new ProdDetail(1234,"iPhone 11 Pro","Apple",1200);
		ProdDetail a2 = new ProdDetail(6824,"Pixel 4","Google",800);
		ProdDetail a3 = new ProdDetail(4567,"Pixel 3a","Google",400);
		ProdDetail a4 = new ProdDetail(3456,"iPhone XS Max","Apple",800);
		ProdDetail a5 = new ProdDetail(5624,"OnePlus 7 Pro","OnePlus",900);
		ProdDetail a6 = new ProdDetail(3205,"OnePlus 7T Pro McLaren","OnePlus",1000);
		ProdDetail a7 = new ProdDetail(7532,"Pixel 2","Google",500);
		ProdDetail a8 = new ProdDetail(2134,"OnePlus 7","OnePlus",600);
		
		datas.add(a1);datas.add(a2);datas.add(a3); datas.add(a4);datas.add(a5);datas.add(a6);datas.add(a7);datas.add(a8);
		
		
	}
	public static void main( String[] args )
	{
		new ProductDetailsUsingList();
    }
	
}
