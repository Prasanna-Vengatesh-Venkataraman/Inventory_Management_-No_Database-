package Data;

public class ProdDetail {
	
	public int productID;					//Individual product details
	public String productInfo;
	public String manufacturer;
	public double cost;
	
	public ProdDetail(int productID, String productInfo, String manufacturer,
			double cost) {
		super();
		this.productID = productID;
		this.productInfo = productInfo;
		this.manufacturer = manufacturer;
		this.cost = cost;
	}

	public int getProductID() {						// Getters and Setters for each details of the product
		return productID;
	}

	public void setProductID(int productID) {
		this.productID = productID;
	}

	public String getProductInfo() {
		return productInfo;
	}

	public void setProductInfo(String productInfo) {
		this.productInfo = productInfo;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

		
   @Override
    public String toString() {
        return "Product{" +
                "ProductID='" + productID + '\'' +
                ", ProductInfo='" + productInfo + '\'' +
                ", Manufacturer='" + manufacturer + '\'' +
                ", Cost='" + cost + '\'' +
                '}';
    } 
	
}
