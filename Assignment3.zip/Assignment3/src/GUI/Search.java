package GUI;
import Data.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Search extends JFrame
{
	JTextArea tbsearch = new JTextArea();					//GUI Components Declaration
	JTextArea tbpid = new JTextArea();
	JTextArea tbprod = new JTextArea();
	JTextArea tbcost = new JTextArea();
	JTextArea tbmanu = new JTextArea();
	
	JButton bsearch = new JButton("SEARCH");
	JButton menu = new JButton("MENU");
	
	String[] choices = { "PRODUCT ID", "PRODUCT", "COST", "MANUFACTURER"};
	JComboBox<String> cbchoices = new JComboBox<String>(choices);
	
	public Search()
	{		
		setExtendedState(MAXIMIZED_BOTH);						//GUI Components Formatting
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = getContentPane();
		Action act = new Action();
		
		JLabel lpid = new JLabel("PRODUCT ID");
		lpid.setFont(new Font("Arial",Font.BOLD,30));
		lpid.setBounds(100, 150, 190, 40);
		lpid.setForeground(Color.RED);
		cp.add(lpid);
		
		tbpid.setBounds(100, 195, 190, 620);
		tbpid.setFont(new Font("Arial",Font.BOLD,25));
		tbpid.setEditable(false);
		cp.add(tbpid);
		
		JLabel lprod = new JLabel("PRODUCT");
		lprod.setFont(new Font("Arial",Font.BOLD,30));
		lprod.setBounds(300, 150, 490, 40);
		lprod.setForeground(Color.RED);
		cp.add(lprod);
		
		tbprod.setBounds(300, 195, 490, 620);
		tbprod.setFont(new Font("Arial",Font.BOLD,25));
		tbprod.setEditable(false);
		cp.add(tbprod);
		
		JLabel lcost = new JLabel("COST");
		lcost.setFont(new Font("Arial",Font.BOLD,30));
		lcost.setBounds(800, 150, 190, 40);
		lcost.setForeground(Color.RED);
		cp.add(lcost);
		
		tbcost.setBounds(800, 195, 190, 620);
		tbcost.setFont(new Font("Arial",Font.BOLD,25));
		tbcost.setEditable(false);
		cp.add(tbcost);
		
		JLabel lmanu = new JLabel("MANUFACTURER");
		lmanu.setFont(new Font("Arial",Font.BOLD,30));
		lmanu.setBounds(1000, 150, 390, 40);
		lmanu.setForeground(Color.RED);
		cp.add(lmanu);
		
		tbmanu.setBounds(1000, 195, 390, 620);
		tbmanu.setFont(new Font("Arial",Font.BOLD,25));
		tbmanu.setEditable(false);
		cp.add(tbmanu);
		
		tbsearch.setBounds(310, 40, 920, 40);
		tbsearch.setFont(new Font("Arial",Font.BOLD,30));
		cp.add(tbsearch);
		
		cbchoices.setBounds(100, 40, 200, 40);
		cbchoices.setFont(new Font("Arial",Font.PLAIN,20));
		cp.add(cbchoices);
		
		bsearch.setBounds(1240,40,150,40);
		bsearch.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(bsearch);
		bsearch.addActionListener(act);
		
		menu.setBounds(1400, 40, 120, 40);
		menu.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(menu);
		menu.addActionListener(act);
		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/Third.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		
		setVisible(true);
	}
	
	public static void main(String[] args) 
	{
		new Search();
	}
	
	class Action implements ActionListener
	{
		public void actionPerformed(ActionEvent act) 
		{
			if(act.getSource()==menu)					//Navigation to main menu
			{
				Second a = new Second();
				a.setVisible(true);
				setVisible(false);
			}
			
			if(act.getSource() == bsearch)
			{
				tbpid.setText(null); tbprod.setText(null); tbcost.setText(null); tbmanu.setText(null);
				
				int count = 0;
				String a = (String) cbchoices.getSelectedItem();
				switch(a)
				{
				case "PRODUCT ID":					//Search based on Product ID
				try {
					for(int i=0; i< Data.ProductDetailsUsingList.datas.size(); i++ )
						{
							if (Data.ProductDetailsUsingList.datas.get(i).productID == Integer.parseInt(tbsearch.getText()))
							{
								tbpid.append(Integer.toString(Data.ProductDetailsUsingList.datas.get(i).productID)+"\n");
								tbprod.append(Data.ProductDetailsUsingList.datas.get(i).productInfo+"\n");
								tbcost.append("$ "+ Double.toString(Data.ProductDetailsUsingList.datas.get(i).cost)+"0"+"\n");
								tbmanu.append(Data.ProductDetailsUsingList.datas.get(i).manufacturer+"\n");
								count++;
							}
							
						}
					
					if(count == 0)					//No match Result
					{
						JLabel msg= new JLabel("No matches for Product ID = " + tbsearch.getText());
						msg.setFont(new Font("Arial",Font.BOLD,15));
						JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
					}
				}
				
				catch(Exception e)						//Exception Handling for wrong Format
				{
					WrongFormat();
				}
					break;
					
				case "PRODUCT":									//Search based on Product name
				
					try
					{
						for(int i=0; i< Data.ProductDetailsUsingList.datas.size(); i++ )
					
						{
							if (Data.ProductDetailsUsingList.datas.get(i).productInfo.equalsIgnoreCase(tbsearch.getText()))
							{
								tbpid.append(Integer.toString(Data.ProductDetailsUsingList.datas.get(i).productID)+"\n");
								tbprod.append(Data.ProductDetailsUsingList.datas.get(i).productInfo+"\n");
								tbcost.append("$ "+ Double.toString(Data.ProductDetailsUsingList.datas.get(i).cost)+"0"+"\n");
								tbmanu.append(Data.ProductDetailsUsingList.datas.get(i).manufacturer+"\n");
								count++;
							}
							
						}
					
						if(count == 0)				//No match Result
						{
							JLabel msg= new JLabel("No matches for Product = " + tbsearch.getText());
							msg.setFont(new Font("Arial",Font.BOLD,15));
							JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
						}
					}
					
						catch(Exception e)			//Exception Handling for wrong Format
						{
							WrongFormat();
						}
				
					break;
					
					
				case "COST":				//Search based on Cost
					try
					{
						for(int i=0; i< Data.ProductDetailsUsingList.datas.size(); i++ )
					
						{
							if (Data.ProductDetailsUsingList.datas.get(i).cost == Double.parseDouble(tbsearch.getText()))
							{
								tbpid.append(Integer.toString(Data.ProductDetailsUsingList.datas.get(i).productID)+"\n");
								tbprod.append(Data.ProductDetailsUsingList.datas.get(i).productInfo+"\n");
								tbcost.append("$ "+ Double.toString(Data.ProductDetailsUsingList.datas.get(i).cost)+"0"+"\n");
								tbmanu.append(Data.ProductDetailsUsingList.datas.get(i).manufacturer+"\n");
								count++;
							}
							
						}
					
						if(count == 0)				//No match Result
						{
							JLabel msg= new JLabel("No matches for Cost = " + tbsearch.getText());
							msg.setFont(new Font("Arial",Font.BOLD,15));
							JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
						}
					}
					
					catch(Exception e)			//Exception Handling for wrong Format
					{
						WrongFormat();
					}
					
					break;
					
					
				case "MANUFACTURER":			//Search based on Manufacturer Name
					try
					{
						for(int i=0; i< Data.ProductDetailsUsingList.datas.size(); i++ )
						{
							if (Data.ProductDetailsUsingList.datas.get(i).manufacturer.equalsIgnoreCase(tbsearch.getText()))
							{
								tbpid.append(Integer.toString(Data.ProductDetailsUsingList.datas.get(i).productID)+"\n");
								tbprod.append(Data.ProductDetailsUsingList.datas.get(i).productInfo+"\n");
								tbcost.append("$ "+ Double.toString(Data.ProductDetailsUsingList.datas.get(i).cost)+"0"+"\n");
								tbmanu.append(Data.ProductDetailsUsingList.datas.get(i).manufacturer+"\n");
								count++;
							}
							
						}
					
						if(count == 0)				//No match Result
						{
							JLabel msg= new JLabel("No matches for Manufacturer = " + tbsearch.getText());
							msg.setFont(new Font("Arial",Font.BOLD,15));
							JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
						}
					}
						
						catch(Exception e)			//Exception Handling for wrong Format
						{
							WrongFormat();
						}
					break;
					
				}
			}
		}
	}
	
	public static void WrongFormat()			//Message to display while searching using a wrong data format
	{
		JLabel msg= new JLabel("Wrong Format");
		msg.setFont(new Font("Arial",Font.BOLD,15));
		JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
	}
}
