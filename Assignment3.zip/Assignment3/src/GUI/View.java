package GUI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;
import Data.*;


public class View extends JFrame
{
	JTextArea tbpid = new JTextArea();						//GUI Components Declaration
	JTextArea tbprod = new JTextArea();
	JTextArea tbcost = new JTextArea();
	JTextArea tbmanu = new JTextArea();
	
	JButton menu = new JButton("MENU");
	
	JRadioButton rbpid = new JRadioButton("PRODUCT ID");
	JRadioButton rbprod = new JRadioButton("PRODUCT");
	JRadioButton rbcost = new JRadioButton("COST");
	JRadioButton rbmanu = new JRadioButton("MANUFACTURER");
	
	ButtonGroup pdbg = new ButtonGroup();
	
	public View()
	{
		setExtendedState(MAXIMIZED_BOTH);				//GUI Components Formatting
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = getContentPane();
		Action act = new Action();
		
		JLabel lpid = new JLabel("PRODUCT ID");
		lpid.setFont(new Font("Arial",Font.BOLD,30));
		lpid.setBounds(100, 50, 190, 40);
		lpid.setForeground(Color.RED);
		cp.add(lpid);
		
		tbpid.setBounds(100, 95, 190, 720);
		tbpid.setFont(new Font("Arial",Font.BOLD,25));
		tbpid.setEditable(false);
		cp.add(tbpid);
		
		JLabel lprod = new JLabel("PRODUCT");
		lprod.setFont(new Font("Arial",Font.BOLD,30));
		lprod.setBounds(300, 50, 490, 40);
		lprod.setForeground(Color.RED);
		cp.add(lprod);
		
		tbprod.setBounds(300, 95, 490, 720);
		tbprod.setFont(new Font("Arial",Font.BOLD,25));
		tbprod.setEditable(false);
		cp.add(tbprod);
		
		JLabel lcost = new JLabel("COST");
		lcost.setFont(new Font("Arial",Font.BOLD,30));
		lcost.setBounds(800, 50, 190, 40);
		lcost.setForeground(Color.RED);
		cp.add(lcost);
		
		tbcost.setBounds(800, 95, 190, 720);
		tbcost.setFont(new Font("Arial",Font.BOLD,25));
		tbcost.setEditable(false);
		cp.add(tbcost);
		
		JLabel lmanu = new JLabel("MANUFACTURER");
		lmanu.setFont(new Font("Arial",Font.BOLD,30));
		lmanu.setBounds(1000, 50, 390, 40);
		lmanu.setForeground(Color.RED);
		cp.add(lmanu);
		
		tbmanu.setBounds(1000, 95, 280, 720);
		tbmanu.setFont(new Font("Arial",Font.BOLD,25));
		tbmanu.setEditable(false);
		cp.add(tbmanu);
		
		menu.setBounds(1400, 40, 120, 40);
		menu.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(menu);
		menu.addActionListener(act);
		
		JLabel lsort = new JLabel("SORT BY");
		lsort.setFont(new Font("Arial",Font.BOLD,30));
		lsort.setBounds(1330, 270, 140, 50);
		lsort.setForeground(Color.WHITE);
		lsort.setBackground(Color.BLACK);
		lsort.setOpaque(true);
		cp.add(lsort);
		
		rbpid.setBounds(1300, 320, 200, 50);
		rbpid.setForeground(Color.WHITE);
		rbpid.setOpaque(false);
		rbpid.setFont(new Font("Arial", Font.BOLD,25));
		cp.add(rbpid);
		rbpid.addActionListener(act);
		
		rbprod.setBounds(1300, 370, 200, 50);
		rbprod.setForeground(Color.WHITE);
		rbprod.setOpaque(false);
		rbprod.setFont(new Font("Arial", Font.BOLD,25));
		cp.add(rbprod);
		rbprod.addActionListener(act);
		
		rbcost.setBounds(1300, 420, 200, 50);
		rbcost.setForeground(Color.WHITE);
		rbcost.setOpaque(false);
		rbcost.setFont(new Font("Arial", Font.BOLD,25));
		cp.add(rbcost);
		rbcost.addActionListener(act);
		
		rbmanu.setBounds(1300, 470, 250, 50);
		rbmanu.setForeground(Color.WHITE);
		rbmanu.setOpaque(false);
		rbmanu.setFont(new Font("Arial", Font.BOLD,25));
		cp.add(rbmanu);
		rbmanu.addActionListener(act);
		
		pdbg.add(rbpid);
		pdbg.add(rbprod);
		pdbg.add(rbcost);
		pdbg.add(rbmanu);
		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/Third.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		
		setVisible(true);
	}
	
	public static void main(String[] args) 
	{
		new View();
	}
	
	class Action implements ActionListener
	{
		public void actionPerformed(ActionEvent act) 
		{
			if(act.getSource()==menu)					//Navigation back to main menu
			{
				Second a = new Second();
				a.setVisible(true);
				setVisible(false);
			}
			
			
			if(act.getSource()==rbpid)				//Sorting based on Product ID
			{
					ArrayList<ProdDetail> datas2 = new ArrayList<ProdDetail>();
					datas2 = Data.ProductDetailsUsingList.datas;
					
					for(int i=0; i<datas2.size()-1; i++)
						for(int j=i+1; j<datas2.size(); j++)
						{
							if(datas2.get(i).productID > datas2.get(j).productID )
							{
								swap (datas2.get(i), datas2.get(j));								
							}
						}
					
					Print(datas2, tbpid, tbprod, tbcost, tbmanu);
				}
			
			
			if(act.getSource()==rbprod)				//Sorting based on Product Field
			{
					ArrayList<ProdDetail> datas2 = new ArrayList<ProdDetail>();
					datas2 = Data.ProductDetailsUsingList.datas;
					
					for(int i=0; i<datas2.size()-1; i++)
						for(int j=i+1; j<datas2.size(); j++)
						{
							if(datas2.get(i).productInfo.toLowerCase().compareTo(datas2.get(j).productInfo.toLowerCase()) > 0 )
							{
								swap (datas2.get(i), datas2.get(j));								
							}
						}
					
					Print(datas2, tbpid, tbprod, tbcost, tbmanu);
				}
			
			
			if(act.getSource()==rbcost)					//Sorting based on cost
			{
					ArrayList<ProdDetail> datas2 = new ArrayList<ProdDetail>();
					datas2 = Data.ProductDetailsUsingList.datas;
					
					for(int i=0; i<datas2.size()-1; i++)
						for(int j=i+1; j<datas2.size(); j++)
						{
							if(datas2.get(i).cost > datas2.get(j).cost )
							{
								swap (datas2.get(i), datas2.get(j));								
							}
						}
					
					Print(datas2, tbpid, tbprod, tbcost, tbmanu);
				}
			
			
			if(act.getSource()==rbmanu)				//Sorting based on manufacturer
			{
					ArrayList<ProdDetail> datas2 = new ArrayList<ProdDetail>();
					datas2 = Data.ProductDetailsUsingList.datas;
					
					for(int i=0; i<datas2.size()-1; i++)
						for(int j=i+1; j<datas2.size(); j++)
						{
							if(datas2.get(i).manufacturer.toLowerCase().compareTo(datas2.get(j).manufacturer.toLowerCase()) > 0 )
							{
								swap (datas2.get(i), datas2.get(j));								
							}
						}
					
					Print(datas2, tbpid, tbprod, tbcost, tbmanu);
				}
			
			}
			
		}

	
	public static void swap(ProdDetail a, ProdDetail b)				//Function for swapping of objects details while sorting
	{
		
		int temppid; double tempcost; String tempproductInfo, tempmanufacturer;
		
		temppid = a.productID;
		tempcost = a.cost;
		tempproductInfo = a.productInfo;
		tempmanufacturer = a.manufacturer;
		
		a.productID = b.productID;
		a.cost = b.cost;
		a.productInfo = b.productInfo;
		a.manufacturer = b.manufacturer;
		
		b.productID = temppid;
		b.cost = tempcost;
		b.productInfo = tempproductInfo;
		b.manufacturer = tempmanufacturer;	
	}
	
	public static void Print (ArrayList<ProdDetail> a, JTextArea tbpid, JTextArea tbprod, JTextArea tbcost, JTextArea tbmanu)  //Print result after swapping is completed
	{
		tbpid.setText(null); tbprod.setText(null); tbcost.setText(null); tbmanu.setText(null);
		
		for(int i=0; i< a.size(); i++ )
		{
			tbpid.append(Integer.toString(a.get(i).productID)+"\n");
			tbprod.append(a.get(i).productInfo+"\n");
			tbcost.append("$ "+Double.toString(a.get(i).cost)+"0"+"\n");
			tbmanu.append(a.get(i).manufacturer+"\n");
		}
	}

}
