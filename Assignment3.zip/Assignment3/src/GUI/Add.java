package GUI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import Data.*;

public class Add extends JFrame
{
	JTextArea tbpid = new JTextArea();							//GUI Components Declaration
	JTextArea tbprod = new JTextArea();
	JTextArea tbcost = new JTextArea();
	JTextArea tbmanu = new JTextArea();	
	
	JButton badd = new JButton("ADD");
	JButton menu = new JButton("MENU");
	
	public Add()
	{
		setExtendedState(MAXIMIZED_BOTH);					//GUI Components formatting
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = getContentPane();
		Action act = new Action();
		
		JLabel lpid = new JLabel("PRODUCT ID");
		lpid.setFont(new Font("Arial",Font.BOLD,30));
		lpid.setBounds(100, 150, 280, 40);
		lpid.setForeground(Color.RED);
		lpid.setBackground(Color.BLACK);
		lpid.setOpaque(true);
		cp.add(lpid);
		
		tbpid.setBounds(400, 150 , 900, 40);
		tbpid.setFont(new Font("Arial",Font.BOLD,30));
		cp.add(tbpid);
		
		JLabel lprod = new JLabel("PRODUCT");
		lprod.setFont(new Font("Arial",Font.BOLD,30));
		lprod.setBounds(100, 250, 280, 40);
		lprod.setForeground(Color.RED);
		lprod.setBackground(Color.BLACK);
		lprod.setOpaque(true);
		cp.add(lprod);	
		
		tbprod.setBounds(400, 250 , 900, 40);
		tbprod.setFont(new Font("Arial",Font.BOLD,30));
		cp.add(tbprod);
		
		JLabel lcost = new JLabel("COST");
		lcost.setFont(new Font("Arial",Font.BOLD,30));
		lcost.setBounds(100, 350, 280, 40);
		lcost.setForeground(Color.RED);
		lcost.setBackground(Color.BLACK);
		lcost.setOpaque(true);
		cp.add(lcost);
			
		tbcost.setBounds(400, 350 , 900, 40);
		tbcost.setFont(new Font("Arial",Font.BOLD,30));
		cp.add(tbcost);
		
		JLabel lmanu = new JLabel("MANUFACTURER");
		lmanu.setFont(new Font("Arial",Font.BOLD,30));
		lmanu.setBounds(100, 450, 280, 40);
		lmanu.setForeground(Color.RED);
		lmanu.setBackground(Color.BLACK);
		lmanu.setOpaque(true);
		cp.add(lmanu);
		
		tbmanu.setBounds(400, 450 , 900, 40);
		tbmanu.setFont(new Font("Arial",Font.BOLD,30));
		cp.add(tbmanu);
		
		badd.setBounds(670,570,150,40);
		badd.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(badd);
		badd.addActionListener(act);
		
		menu.setBounds(1400, 40, 120, 40);
		menu.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(menu);
		menu.addActionListener(act);
		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/Third.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		
		setVisible(true);
	}
	
	public static void main(String[] args) 
	{
		new Add();
	}
	
	class Action implements ActionListener
	{
		public void actionPerformed(ActionEvent act) 
		{
			if(act.getSource()==menu)								//Navigation back to Main menu
			{
				Second a = new Second();
				a.setVisible(true);
				setVisible(false);
			}
			
			if(act.getSource() == badd)								//Addition of new product to the list
			{
				try
				{
				
				int count=0;
				int pid=Integer.parseInt(tbpid.getText());
				for(int i=0; i< Data.ProductDetailsUsingList.datas.size(); i++) 
				{
					if(pid==Data.ProductDetailsUsingList.datas.get(i).productID)
					{
						JLabel msg= new JLabel("Product ID = " + tbpid.getText()+" already present");		//Verification if new Product ID is already present
						msg.setFont(new Font("Arial",Font.BOLD,15));
						JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
						tbpid.setText(null);
						count=1;
					}
					continue;
				}
				
				if(count!=1)							//Successful addition of new product
				{
					Data.ProductDetailsUsingList.datas.add(new Data.ProdDetail(pid, tbprod.getText() , tbmanu.getText(), Double.parseDouble(tbcost.getText())));
					JLabel msg= new JLabel("Product successfully added");
					msg.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg,"SUCCESS",JOptionPane.PLAIN_MESSAGE);
					tbpid.setText(null); tbprod.setText(null); tbcost.setText(null); tbmanu.setText(null);
				}
				
				}
			
				catch(Exception e)						//Exception Handling for incorrect data format
				{
					JLabel msg= new JLabel("Wrong Format. Kindly re-check all fields ");
					msg.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
				}
			}
		}
	}
}
