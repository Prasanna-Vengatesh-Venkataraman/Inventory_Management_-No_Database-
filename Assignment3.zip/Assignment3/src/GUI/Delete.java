package GUI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ListIterator;

import javax.swing.*;
import Data.*;

public class Delete extends JFrame
{
	JTextArea tbsearch = new JTextArea();					//GUI Components Declaration
	JTextArea tbpid = new JTextArea();
	JTextArea tbprod = new JTextArea();
	JTextArea tbcost = new JTextArea();
	JTextArea tbmanu = new JTextArea();
	
	JButton bsearch = new JButton("SEARCH");
	JButton bdelete = new JButton("DELETE");
	JButton menu = new JButton("MENU");
	
	public Delete()
	{
		setExtendedState(MAXIMIZED_BOTH);				//GUI Components Formatting
		setResizable(false);
		pack();
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = getContentPane();
		Action act = new Action();
		
		JLabel lpid = new JLabel("PRODUCT ID");
		lpid.setFont(new Font("Arial",Font.BOLD,30));
		lpid.setBounds(100, 250, 280, 40);
		lpid.setForeground(Color.RED);
		lpid.setBackground(Color.BLACK);
		lpid.setOpaque(true);
		cp.add(lpid);
		
		tbpid.setBounds(400, 250 , 900, 40);
		tbpid.setFont(new Font("Arial",Font.BOLD,30));
		tbpid.setEditable(false);
		cp.add(tbpid);
		
		JLabel lprod = new JLabel("PRODUCT");
		lprod.setFont(new Font("Arial",Font.BOLD,30));
		lprod.setBounds(100, 350, 280, 40);
		lprod.setForeground(Color.RED);
		lprod.setBackground(Color.BLACK);
		lprod.setOpaque(true);
		cp.add(lprod);	
		
		tbprod.setBounds(400, 350 , 900, 40);
		tbprod.setFont(new Font("Arial",Font.BOLD,30));
		tbprod.setEditable(false);
		cp.add(tbprod);
		
		JLabel lcost = new JLabel("COST");
		lcost.setFont(new Font("Arial",Font.BOLD,30));
		lcost.setBounds(100, 450, 280, 40);
		lcost.setForeground(Color.RED);
		lcost.setBackground(Color.BLACK);
		lcost.setOpaque(true);
		cp.add(lcost);
			
		tbcost.setBounds(400, 450 , 900, 40);
		tbcost.setFont(new Font("Arial",Font.BOLD,30));
		tbcost.setEditable(false);
		cp.add(tbcost);
		
		JLabel lmanu = new JLabel("MANUFACTURER");
		lmanu.setFont(new Font("Arial",Font.BOLD,30));
		lmanu.setBounds(100, 550, 280, 40);
		lmanu.setForeground(Color.RED);
		lmanu.setBackground(Color.BLACK);
		lmanu.setOpaque(true);
		cp.add(lmanu);
		
		tbmanu.setBounds(400, 550 , 900, 40);
		tbmanu.setFont(new Font("Arial",Font.BOLD,30));
		tbmanu.setEditable(false);
		cp.add(tbmanu);
		
		JLabel lpid2 = new JLabel("PRODUCT ID");
		lpid2.setFont(new Font("Arial",Font.BOLD,30));
		lpid2.setBounds(100, 40, 200, 40);
		lpid2.setForeground(Color.RED);
		lpid2.setBackground(Color.BLACK);
		lpid2.setOpaque(true);
		cp.add(lpid2);
		
		
		tbsearch.setBounds(310, 40, 920, 40);
		tbsearch.setFont(new Font("Arial",Font.BOLD,30));
		cp.add(tbsearch);
		
		bsearch.setBounds(1240,40,150,40);
		bsearch.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(bsearch);
		bsearch.addActionListener(act);
		
		bdelete.setBounds(670,670,150,40);
		bdelete.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(bdelete);
		bdelete.addActionListener(act);
		
		menu.setBounds(1400, 40, 120, 40);
		menu.setFont(new Font("Arial",Font.BOLD,20));
		cp.add(menu);
		menu.addActionListener(act);
		
		cp.setLayout(new BorderLayout());
		
		ImageIcon bg = new ImageIcon("src/Third.jpg");
		JLabel background = new JLabel(bg);
		cp.add(background);
		
		
		setVisible(true);
	}
	
	public static void main(String[] args) 
	{
		new Delete();
	}
	
	class Action implements ActionListener
	{
		public void actionPerformed(ActionEvent act) 
		{
			if(act.getSource()==menu)					//Navigation to main menu
			{
				Second a = new Second();
				a.setVisible(true);
				setVisible(false);
			}
			
			if (act.getSource() == bsearch) 			//Search for a component using Product ID
			{
				try
				{
				int count = 0;
				for (int i = 0; i < Data.ProductDetailsUsingList.datas.size(); i++) 
				{
					if (Data.ProductDetailsUsingList.datas.get(i).productID == Integer.parseInt(tbsearch.getText())) 
					{
						tbpid.append(Integer.toString(Data.ProductDetailsUsingList.datas.get(i).productID) + "\n");
						tbprod.append(Data.ProductDetailsUsingList.datas.get(i).productInfo + "\n");
						tbcost.append("$ " + Double.toString(Data.ProductDetailsUsingList.datas.get(i).cost) + "0" + "\n");
						tbmanu.append(Data.ProductDetailsUsingList.datas.get(i).manufacturer + "\n");
						count++;
					}
				}

				if (count == 0) 				//Message to display for no matches
				{
					JLabel msg = new JLabel("No matches for Product ID = " + tbsearch.getText());
					msg.setFont(new Font("Arial", Font.BOLD, 15));
					JOptionPane.showMessageDialog(null, msg, "Error", JOptionPane.ERROR_MESSAGE);
				}


			}
				
				catch(Exception e)			//Exception Handling for wrong data format
				{
					JLabel msg= new JLabel("Kindly search a product before deleting");
					msg.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
				}
			}
			
			if (act.getSource() == bdelete) 			//Delete product after successful search
			{
				try
				{String s = tbpid.getText().strip();
				int pid = Integer.parseInt(s);
				
				ListIterator<ProdDetail> it=Data.ProductDetailsUsingList.datas.listIterator();
				Boolean flag=true;
				while(it.hasNext()) 
				{
					ProdDetail temp=it.next();
					if(temp.productID==pid) 
					{
						it.remove();
						JLabel msg= new JLabel("Product successfully deleted");
						msg.setFont(new Font("Arial",Font.BOLD,15));
						JOptionPane.showMessageDialog(null,msg,"SUCCESS",JOptionPane.PLAIN_MESSAGE);
						tbpid.setText(null); tbprod.setText(null); tbcost.setText(null); tbmanu.setText(null); tbsearch.setText(null);
						flag=false;
						break;
					}
				}
				
//				if(flag) 
//				{
//					JLabel msg = new JLabel("Cannot delete non existatnt Product ID = " + tbpid.getText());
//					msg.setFont(new Font("Arial", Font.BOLD, 15));
//					JOptionPane.showMessageDialog(null, msg, "Error", JOptionPane.ERROR_MESSAGE);
//				}
				}
				
				catch(Exception e)					//Exception Handling for wrong data format
				{
					JLabel msg= new JLabel("Kindly search a product before deleting");
					msg.setFont(new Font("Arial",Font.BOLD,15));
					JOptionPane.showMessageDialog(null,msg,"Error",JOptionPane.ERROR_MESSAGE);
				}
			}
		}
	}
}